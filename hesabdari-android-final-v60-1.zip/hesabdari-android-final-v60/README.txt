حسابداری خانگی — Android Build نهایی

نسخه برنامه: 60
لوگو: لوگوی تاییدشده NEGIN YARAGH
پکیج: com.neginyaragh.hesabdari

روش ساخت APK:
1) فایل ZIP را Extract کنید.
2) Android Studio را باز کنید.
3) گزینه Open را بزنید و پوشه hesabdari-android-final-v60 را انتخاب کنید.
4) صبر کنید Gradle Sync کامل شود.
5) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را بزنید.
6) پس از پایان، روی Locate بزنید.

مسیر معمول APK:
app/build/outputs/apk/debug/app-debug.apk

این پروژه نسخه منتشرشده حسابداری خانگی را داخل اپ اندروید نمایش می‌دهد و برای اجرا به اینترنت نیاز دارد.
