حسابداری خانگی - Android Build v61

این پروژه یک Android WebView برای نسخه زنده برنامه حسابداری خانگی است.
آدرس برنامه:
https://hsabdary-khangy.hatchable.site

نسخه: 61
versionCode: 61

ساخت APK در Android Studio:
1) این پوشه را در Android Studio به عنوان پروژه Gradle باز کنید.
2) Gradle Sync را انجام دهید.
3) از منوی Build گزینه Build APK(s) را انتخاب کنید.
4) فایل APK ساخته‌شده را از پوشه app/build/outputs/apk/ پیدا کنید.

توجه: این نسخه برای نمایش برنامه زنده به اینترنت نیاز دارد.
